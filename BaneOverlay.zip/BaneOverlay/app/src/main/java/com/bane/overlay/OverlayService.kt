package com.bane.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.floor

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val prefs by lazy { getSharedPreferences("bane", MODE_PRIVATE) }
    private val accent = 0xFF7C5CFF.toInt()
    private val muted = 0xFF8A92A6.toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        showBubble()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        closePanel()
        bubble?.let { wm.removeView(it) }
        bubble = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bane", "Bane Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bane")
            .setContentTitle("Bane Overlay çalışıyor")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- Yuvarlak top ----------
    private fun showBubble() {
        val size = dp(56)
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
            elevation = dp(6).toFloat()
            val f = File(filesDir, "bubble.png")
            if (f.exists()) setImageBitmap(BitmapFactory.decodeFile(f.path))
            else setImageDrawable(GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) })
        }
        val lp = LP(size, size, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(200)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        iv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(iv, lp)
        bubble = iv
    }

    // ---------- Yan menü ----------
    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    private fun closePanel() { panel?.let { wm.removeView(it) }; panel = null }

    private fun label(t: String, size: Float = 13f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun edit(h: String) = EditText(this).apply {
        hint = h; setHintTextColor(muted); setTextColor(Color.WHITE); textSize = 14f
        setSingleLine()
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
    }

    private fun textEdit(h: String) = EditText(this).apply {
        hint = h; setHintTextColor(muted); setTextColor(Color.WHITE); textSize = 14f; setSingleLine()
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
    }

    private fun loadPos() = JSONArray(prefs.getString("pos", "[]"))
    private fun savePos(a: JSONArray) { prefs.edit().putString("pos", a.toString()).apply() }

    private fun openPanel() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        // başlık
        col.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(label("BANE.CLIENT", 16f, Color.WHITE, true), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(btn("✕") { closePanel() }, LinearLayout.LayoutParams(dp(52), dp(44)))
        })

        // 1) Konumlar
        col.addView(label("📍 Konumlar", 14f, accent, true).apply { setPadding(0, dp(14), 0, 0) })
        val nameE = textEdit("Ad (Ev, Maden…)")
        val xE = edit("X"); val yE = edit("Y"); val zE = edit("Z")
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refresh() {
            list.removeAllViews()
            val a = loadPos()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                r.addView(label("${o.getString("n")}\n${o.getInt("x")}, ${o.getInt("y")}, ${o.getInt("z")}", 13f, Color.WHITE),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                r.addView(btn("✕") { val arr = loadPos(); arr.remove(i); savePos(arr); refresh() },
                    LinearLayout.LayoutParams(dp(52), dp(44)))
                list.addView(r)
            }
        }
        col.addView(nameE)
        col.addView(row(xE, yE, zE))
        col.addView(btn("Kaydet") {
            val n = nameE.text.toString().trim()
            val x = xE.text.toString().toIntOrNull(); val y = yE.text.toString().toIntOrNull(); val z = zE.text.toString().toIntOrNull()
            if (n.isEmpty() || x == null || y == null || z == null) return@btn
            val a = loadPos()
            a.put(JSONObject().put("n", n).put("x", x).put("y", y).put("z", z))
            savePos(a); refresh()
            nameE.setText(""); xE.setText(""); yE.setText(""); zE.setText("")
        })
        col.addView(list)
        refresh()

        // 2) Nether çevirici
        col.addView(label("🔥 Nether çevirici", 14f, accent, true).apply { setPadding(0, dp(18), 0, 0) })
        val nx = edit("X"); val nz = edit("Z")
        val nres = label("", 14f, Color.WHITE, true)
        fun calc(f: Double) {
            val x = nx.text.toString().toDoubleOrNull(); val z = nz.text.toString().toDoubleOrNull()
            if (x == null || z == null) return
            nres.text = "X: ${floor(x * f).toInt()}   Z: ${floor(z * f).toInt()}"
        }
        col.addView(row(nx, nz))
        col.addView(btn("Overworld → Nether (÷8)") { calc(1.0 / 8) })
        col.addView(btn("Nether → Overworld (×8)") { calc(8.0) })
        col.addView(nres)

        // 3) Yığın hesabı
        col.addView(label("📦 Yığın hesabı", 14f, accent, true).apply { setPadding(0, dp(18), 0, 0) })
        val sn = edit("Eşya sayısı")
        val sres = label("", 14f, Color.WHITE, true)
        fun stack(size: Int) {
            val n = sn.text.toString().toIntOrNull() ?: return
            if (n < 0) return
            sres.text = "${n / size} yığın + ${n % size} adet\n≈ ${"%.2f".format(n / (size * 27.0))} sandık"
        }
        col.addView(sn)
        col.addView(row(btn("64'lük") { stack(64) }, btn("16'lık") { stack(16) }))
        col.addView(sres)

        val sv = ScrollView(this).apply {
            setBackgroundColor(0xF0171A22.toInt())
            addView(col)
        }
        val lp = LP(dp(300), LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.START or Gravity.TOP
            softInputMode = LP.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(sv, lp)
        panel = sv
    }
}
