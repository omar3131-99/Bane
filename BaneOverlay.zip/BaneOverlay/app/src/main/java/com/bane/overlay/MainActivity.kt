package com.bane.overlay

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val pick = 1

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun button(t: String, f: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(48), dp(24), dp(24))
            setBackgroundColor(0xFF0E1015.toInt())
        }
        root.addView(TextView(this).apply {
            text = "BANE.CLIENT"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Minecraft üzerinde yüzen yardımcı araçlar\n(koordinat kaydı, Nether çevirici, yığın hesabı)"
            setTextColor(0xFF8A92A6.toInt())
            setPadding(0, dp(8), 0, dp(24))
        })
        root.addView(button("1) Üstte gösterme iznini ver") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else toast("İzin zaten verilmiş")
        })
        root.addView(button("2) Top için fotoğraf seç") {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, pick)
        })
        root.addView(button("3) Başlat ve Minecraft'ı aç") { start() })
        root.addView(button("Durdur") {
            stopService(Intent(this, OverlayService::class.java))
        })
        setContentView(root)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun start() {
        if (!Settings.canDrawOverlays(this)) { toast("Önce 1. adımdaki izni ver"); return }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
        startForegroundService(Intent(this, OverlayService::class.java))
        val mc = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (mc != null) startActivity(mc) else toast("Minecraft Bedrock yüklü görünmüyor")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req != pick || res != RESULT_OK || uri == null) return
        try {
            val src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
            val s = 256f / maxOf(src.width, src.height)
            val bmp = Bitmap.createScaledBitmap(src, (src.width * s).toInt().coerceAtLeast(1), (src.height * s).toInt().coerceAtLeast(1), true)
            File(filesDir, "bubble.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            toast("Fotoğraf kaydedildi. Çalışıyorsa Durdur, sonra tekrar Başlat.")
        } catch (e: Exception) {
            toast("Fotoğraf okunamadı")
        }
    }
}
