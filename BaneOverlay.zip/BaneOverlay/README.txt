Bane Overlay - Android Studio projesi
1) Android Studio ile bu klasörü aç (Open).
2) Gradle sync bitince Build > Build APK(s).
3) APK'yı telefona kur, uygulamadaki 1-2-3 adımlarını sırayla yap.
